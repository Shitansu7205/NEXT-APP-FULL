// components/AcmeLogo.jsx

export function AcmeLogo() {
    return (
      <img src="/path-to-your-logo.svg" alt="ACME Logo" style={{ height: '40px' }} />
    );
  }
  